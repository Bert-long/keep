package com.neusoft.sm.api.student.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.neusoft.sm.api.student.dao.StudentDao;
import com.neusoft.sm.api.student.entity.Student;
import com.neusoft.sm.common.dao.DbUtil;
import com.neusoft.sm.common.dao.SqlFileUtil;
import com.neusoft.sm.common.util.AppUtil;

public class StudentDaoImpl implements StudentDao {

	@Override
	public int insert(Student stu) {
		Connection conn = null;
		PreparedStatement pst = null;
		
		conn = DbUtil.getConnection();
		String sql = SqlFileUtil.getSqlFile("/student/insert.sql");
		try {
			pst = conn.prepareStatement(sql);
			pst.setString(1, AppUtil.createUUID());
			pst.setString(2, stu.getStuCode());
			pst.setString(3, stu.getStuName());
			pst.setInt(4, stu.getStuAge());
			pst.setString(5, stu.getStuSex());
			pst.setDate(6, AppUtil.convertToSqlDate(stu.getStuBirhday()) );
			pst.setString(7, stu.getStuClassId());
			
			int cnt = pst.executeUpdate();
			return cnt;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbUtil.close(conn, pst, null);
		}
		return 0;
	}

	@Override
	public int update(Student stu) {
		Connection conn = null;
		PreparedStatement pst = null;
		
		conn = DbUtil.getConnection();
		String sql = SqlFileUtil.getSqlFile("/student/update.sql");
		try {
			pst = conn.prepareStatement(sql);
			pst.setString(1, stu.getStuCode());
			pst.setString(2, stu.getStuName());
			pst.setInt(3, stu.getStuAge());
			pst.setString(4, stu.getStuSex());
			pst.setDate(5, AppUtil.convertToSqlDate(stu.getStuBirhday()) );
			pst.setString(6, stu.getStuClassId());
			pst.setString(7, stu.getId());
			
			int cnt = pst.executeUpdate();
			return cnt;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbUtil.close(conn, pst, null);
		}
		return 0;
	}

	@Override
	public int delete(String id) {
		return 0;
	}

	@Override
	public Student findById(String id) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		
		conn = DbUtil.getConnection();
		String sql = SqlFileUtil.getSqlFile("/student/findbyid.sql");
		try {
			pst = conn.prepareStatement(sql);
			pst.setString(1, id);
			
			rs = pst.executeQuery();
			if(rs.next()) {
				Student student = new Student();
				student.setId(rs.getString(1));
				student.setStuCode(rs.getString(2));
				student.setStuName(rs.getString(3));
				student.setStuAge(rs.getInt(4));
				student.setStuSex(rs.getString(5));
				student.setStuSexName(rs.getString(6));
				student.setStuBirhday(rs.getDate(7));
				student.setStuClassId(rs.getString(8));
				student.setStuClassName(rs.getString(9));
				
				return student;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbUtil.close(conn, pst, rs);
		}
		return null;
	}

	@Override
	public List<Student> findByCond() {
		List<Student> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		
		conn = DbUtil.getConnection();
		String sql = SqlFileUtil.getSqlFile("/student/findall.sql");
		try {
			pst = conn.prepareStatement(sql);
			
			rs = pst.executeQuery();
			while(rs.next()) {
				Student student = new Student();
				student.setId(rs.getString(1));
				student.setStuCode(rs.getString(2));
				student.setStuName(rs.getString(3));
				student.setStuAge(rs.getInt(4));
				student.setStuSex(rs.getString(5));
				student.setStuSexName(rs.getString(6));
				student.setStuBirhday(rs.getDate(7));
				student.setStuClassId(rs.getString(8));
				student.setStuClassName(rs.getString(9));
				
				list.add(student);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbUtil.close(conn, pst, rs);
		}
		return list;
	}

	@Override
	public String findMaxCode() {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		
		conn = DbUtil.getConnection();
		String sql = SqlFileUtil.getSqlFile("/student/findmaxcode.sql");
		try {
			pst = conn.prepareStatement(sql);
			
			rs = pst.executeQuery();
			if(rs.next()) {
				return rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbUtil.close(conn, pst, rs);
		}
		return null;
	}

}
