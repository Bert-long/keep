package com.neusoft.sm.api.codename.service.impl;

import java.util.List;

import com.neusoft.sm.api.codename.dao.CodeNameDao;
import com.neusoft.sm.api.codename.dao.impl.CodeNameDaoImpl;
import com.neusoft.sm.api.codename.entity.CodeName;
import com.neusoft.sm.api.codename.service.CodeNameService;

public class CodeNameServiceImpl implements CodeNameService {
	private CodeNameDao dao = new CodeNameDaoImpl();
	@Override
	public List<CodeName> findByGroupId(String gruopId) {
		return dao.findByGroupId(gruopId);
	}

}
