package com.neusoft.sm.api.codename.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.neusoft.sm.api.codename.dao.CodeNameDao;
import com.neusoft.sm.api.codename.entity.CodeName;
import com.neusoft.sm.common.dao.DbUtil;
import com.neusoft.sm.common.dao.SqlFileUtil;

public class CodeNameDaoImpl implements CodeNameDao {

	@Override
	public List<CodeName> findByGroupId(String gruopId) {
		Connection conn = DbUtil.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<CodeName> list = new ArrayList<>();
		try {
			String sql = SqlFileUtil.getSqlFile("/codename/findbygroupid.sql");
			pst = conn.prepareStatement(sql);
			pst.setString(1, gruopId);
			rs = pst.executeQuery();
			while(rs.next()) {
				CodeName cn = new CodeName();
				cn.setId(rs.getString(1));
				cn.setGroupCode(rs.getString(2));
				cn.setCode(rs.getString(3));
				cn.setName(rs.getString(4));
				list.add(cn);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbUtil.close(conn, pst, rs);
		}
		return list;
	}

}
