package com.neusoft.sm.api.student.ctrl;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neusoft.sm.api.student.entity.Student;
import com.neusoft.sm.api.student.service.StudentService;
import com.neusoft.sm.api.student.service.impl.StudentServiceImpl;

@WebServlet(name="StudentDoAdd", urlPatterns="/student/doadd")
public class StudentDoAdd extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 1. 校验参数
		req.setCharacterEncoding("utf-8");
		String name = req.getParameter("name");
		if(name == null || "".equals(name)) {
			// 没有输入姓名
			throw new RuntimeException();
		}
		String age = req.getParameter("age");
		if(name == null || "".equals(age)) {
			throw new RuntimeException();
		}
		String sex = req.getParameter("sex");
		if(name == null || "".equals(sex)) {
			throw new RuntimeException();
		}
		String birthday = req.getParameter("birthday");
		String classId = req.getParameter("classid");
		if(name == null || "".equals(classId)) {
			throw new RuntimeException();
		}
		
		// 2. service调用
		Student student = new Student();
		student.setStuName(name);
		student.setStuAge(Integer.valueOf(age));
		student.setStuSex(sex);
		if(birthday == null || "".equals(birthday)) {
			student.setStuBirhday(null);
		} else {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			try {
				student.setStuBirhday(sdf.parse(birthday));
			} catch (ParseException e) {
				throw new RuntimeException();
			}
		}
		student.setStuClassId(classId);
		
		StudentService service = new StudentServiceImpl();
		boolean res = service.insert(student);
		
		// 3. 返回结果
		Map<String, Boolean> map = new HashMap<>();
	    map.put("res", res);
	    
	    ObjectMapper om = new ObjectMapper();
		String json = om.writeValueAsString(map);
		
		resp.setContentType("text/json;charset=utf-8");
		PrintWriter pw =  resp.getWriter();
		pw.write(json);
	}
}
