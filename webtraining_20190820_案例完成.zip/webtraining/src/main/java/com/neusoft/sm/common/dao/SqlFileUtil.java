package com.neusoft.sm.common.dao;

import java.io.File;
import java.io.IOException;
import java.io.Writer;

import org.apache.commons.io.output.StringBuilderWriter;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

public class SqlFileUtil {
	private static final String FLT_PATH = "src/main/resources/flt";
	private static final String ENCODING = "utf-8";

	public static String getSqlFile(String fltPath) {
		return getSqlFile(fltPath, null);
	}
	
	public static String getSqlFile(String fltPath, Object data) {
		Configuration configuration = new Configuration(Configuration.getVersion());
		StringBuilder sb = new StringBuilder();
		try(Writer out = new StringBuilderWriter(sb)) {
			configuration.setDirectoryForTemplateLoading(new File(FLT_PATH));
			configuration.setDefaultEncoding(ENCODING);
			Template template = configuration.getTemplate(fltPath);
			template.process(data, out);
		} catch (IOException | TemplateException e) {
			e.printStackTrace();
		} 
		
		return sb.toString();
	}
}
