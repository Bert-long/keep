package com.neusoft.sm.api.clazz.dao;

import java.util.List;

import com.neusoft.sm.api.clazz.entity.StuClass;

public interface ClassDao {
	public List<StuClass> findAll();
}
