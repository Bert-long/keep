package com.neusoft.sm.common.util;

import java.util.Date;
import java.util.UUID;

public class AppUtil {

	public static java.sql.Date convertToSqlDate(Date date) {
		return new java.sql.Date(date.getTime());
	}
	
	public static Date convertToUtilDate(java.sql.Date date) {
		return new Date(date.getTime());
	}
	
	public static String createUUID() {
		return UUID.randomUUID().toString().replace("-", "");
	}
}
