package com.neusoft.sm.api.codename.dao;

import java.util.List;

import com.neusoft.sm.api.codename.entity.CodeName;

public interface CodeNameDao {
	public List<CodeName> findByGroupId(String gruopId);
}
