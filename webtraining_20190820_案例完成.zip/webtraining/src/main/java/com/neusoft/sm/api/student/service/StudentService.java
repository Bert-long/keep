package com.neusoft.sm.api.student.service;

import java.util.List;

import com.neusoft.sm.api.student.entity.Student;

public interface StudentService {
	public boolean insert(Student stu);
	public boolean update(Student stu);
	public boolean delete(String id);
	public Student findById(String id);
	public List<Student> findByCond();
}
