package com.neusoft.sm.common.dao;

public interface BaseDao<T> {
	public T findById(String id);
	
	public int insert(T student);
	
	public int update(T student);
	
	public int delete(String id);
}
