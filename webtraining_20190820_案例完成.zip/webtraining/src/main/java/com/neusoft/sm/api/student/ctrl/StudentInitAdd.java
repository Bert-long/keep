package com.neusoft.sm.api.student.ctrl;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neusoft.sm.api.clazz.entity.StuClass;
import com.neusoft.sm.api.clazz.service.ClassService;
import com.neusoft.sm.api.clazz.service.impl.ClassSeriviceImpl;
import com.neusoft.sm.api.codename.entity.CodeName;
import com.neusoft.sm.api.codename.service.CodeNameService;
import com.neusoft.sm.api.codename.service.impl.CodeNameServiceImpl;

@WebServlet(name="StudentInitAdd", urlPatterns="/student/initadd")
public class StudentInitAdd extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 性别下拉列表数据
		CodeNameService cnService = new CodeNameServiceImpl();
		List<CodeName> cns = cnService.findByGroupId("A01");
		
		// 班级下拉列表数据
		ClassService classSerivce = new ClassSeriviceImpl();
		List<StuClass> classes = classSerivce.findAll();
		
		// HashMap
		Map<String, Object> map = new HashMap<>();
		map.put("cns", cns);
		map.put("classes", classes);
		
		ObjectMapper om = new ObjectMapper();
		String json = om.writeValueAsString(map);
		
		resp.setContentType("text/json;charset=utf-8");
		PrintWriter pw =  resp.getWriter();
		pw.write(json);
	}

}
