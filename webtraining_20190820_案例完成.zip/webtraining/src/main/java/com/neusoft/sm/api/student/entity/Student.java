package com.neusoft.sm.api.student.entity;

import java.util.Date;

public class Student {
	private String id;
	private String stuCode;
	private String stuName;
	private Integer stuAge;
	private Date stuBirhday;
	private String stuSex;
	private String stuSexName;
	private String stuClassId;
	private String stuClassName;
	public String getStuCode() {
		return stuCode;
	}
	public void setStuCode(String stuCode) {
		this.stuCode = stuCode;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public Integer getStuAge() {
		return stuAge;
	}
	public void setStuAge(Integer stuAge) {
		this.stuAge = stuAge;
	}
	public Date getStuBirhday() {
		return stuBirhday;
	}
	public void setStuBirhday(Date stuBirhday) {
		this.stuBirhday = stuBirhday;
	}
	public String getStuSex() {
		return stuSex;
	}
	public void setStuSex(String stuSex) {
		this.stuSex = stuSex;
	}
	public String getStuSexName() {
		return stuSexName;
	}
	public void setStuSexName(String stuSexName) {
		this.stuSexName = stuSexName;
	}
	public String getStuClassId() {
		return stuClassId;
	}
	public void setStuClassId(String stuClassId) {
		this.stuClassId = stuClassId;
	}
	public String getStuClassName() {
		return stuClassName;
	}
	public void setStuClassName(String stuClassName) {
		this.stuClassName = stuClassName;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Student [stuCode=" + stuCode + ", stuName=" + stuName + ", stuAge=" + stuAge + ", stuBirhday="
				+ stuBirhday + ", stuSex=" + stuSex + ", stuSexName=" + stuSexName + ", stuClassId=" + stuClassId
				+ ", stuClassName=" + stuClassName + "]";
	}
}
