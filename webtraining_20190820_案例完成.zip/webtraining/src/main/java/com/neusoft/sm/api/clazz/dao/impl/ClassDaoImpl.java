package com.neusoft.sm.api.clazz.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.neusoft.sm.api.clazz.dao.ClassDao;
import com.neusoft.sm.api.clazz.entity.StuClass;
import com.neusoft.sm.common.dao.DbUtil;
import com.neusoft.sm.common.dao.SqlFileUtil;

public class ClassDaoImpl implements ClassDao {
	public List<StuClass> findAll() {
		List<StuClass> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		
		conn = DbUtil.getConnection();
		String sql = SqlFileUtil.getSqlFile("/clazz/findall.sql");
		try {
			pst = conn.prepareStatement(sql);
			
			rs = pst.executeQuery();
			while(rs.next()) {
				StuClass sc = new StuClass();
				sc.setId(rs.getString(1));
				sc.setName(rs.getString(2));
				
				list.add(sc);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbUtil.close(conn, pst, rs);
		}
		return list;
	}

}
