package com.neusoft.sm.api.clazz.service;

import java.util.List;

import com.neusoft.sm.api.clazz.entity.StuClass;

public interface ClassService {
	public List<StuClass> findAll();
}
