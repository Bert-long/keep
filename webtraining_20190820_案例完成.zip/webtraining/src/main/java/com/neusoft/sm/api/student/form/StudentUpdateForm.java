package com.neusoft.sm.api.student.form;

public class StudentUpdateForm {
	private String id;
	private String stuCode;
	private String stuName;
	private String stuAge;
	private String stuBirhday;
	private String stuSex;
	private String stuClassId;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getStuCode() {
		return stuCode;
	}
	public void setStuCode(String stuCode) {
		this.stuCode = stuCode;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public String getStuAge() {
		return stuAge;
	}
	public void setStuAge(String stuAge) {
		this.stuAge = stuAge;
	}
	public String getStuBirhday() {
		return stuBirhday;
	}
	public void setStuBirhday(String stuBirhday) {
		this.stuBirhday = stuBirhday;
	}
	public String getStuSex() {
		return stuSex;
	}
	public void setStuSex(String stuSex) {
		this.stuSex = stuSex;
	}
	public String getStuClassId() {
		return stuClassId;
	}
	public void setStuClassId(String stuClassId) {
		this.stuClassId = stuClassId;
	}
}
