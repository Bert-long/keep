package com.neusoft.sm.common.util;

public class StringUtil {

	public static boolean isEmpty(String value) {
		if(value == null || "".equals(value)) {
			return true;
		} else {
			return false;
		}
	}
}
