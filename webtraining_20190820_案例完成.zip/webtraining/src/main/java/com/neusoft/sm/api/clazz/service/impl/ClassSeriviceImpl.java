package com.neusoft.sm.api.clazz.service.impl;

import java.util.List;

import com.neusoft.sm.api.clazz.dao.ClassDao;
import com.neusoft.sm.api.clazz.dao.impl.ClassDaoImpl;
import com.neusoft.sm.api.clazz.entity.StuClass;
import com.neusoft.sm.api.clazz.service.ClassService;

public class ClassSeriviceImpl implements ClassService {
	private ClassDao dao = new ClassDaoImpl();
	@Override
	public List<StuClass> findAll() {
		return dao.findAll();
	}

}
