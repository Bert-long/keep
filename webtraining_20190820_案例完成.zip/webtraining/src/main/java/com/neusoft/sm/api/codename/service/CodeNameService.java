package com.neusoft.sm.api.codename.service;

import java.util.List;

import com.neusoft.sm.api.codename.entity.CodeName;

public interface CodeNameService {
	public List<CodeName> findByGroupId(String GruopId);
}
