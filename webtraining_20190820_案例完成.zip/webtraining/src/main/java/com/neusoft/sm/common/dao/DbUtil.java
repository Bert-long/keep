package com.neusoft.sm.common.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DbUtil {
	private static final String URL = "jdbc:mysql://127.0.0.1:3306/sma?useUnicode=true&characterEncoding=UTF-8&allowMultiQueries=true&serverTimezone=GMT%2B8";
	private static final String DIRVER_CLASS = "com.mysql.cj.jdbc.Driver";
	
	public static Connection getConnection() {
		try {
			Class.forName(DIRVER_CLASS);
			Connection conn = DriverManager.getConnection(URL, "root", "123456");
			return conn;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("数据库连接不正确!");
		}
	}
	
	public static void close(Connection conn, PreparedStatement pst, ResultSet rs) {
		try {
			if(rs != null) {
				rs.close();
			}
			if(pst != null) {
				pst.close();
			}
			if(conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
