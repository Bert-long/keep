package com.neusoft.sm.api.student.service.impl;

import java.util.List;

import com.neusoft.sm.api.student.dao.StudentDao;
import com.neusoft.sm.api.student.dao.impl.StudentDaoImpl;
import com.neusoft.sm.api.student.entity.Student;
import com.neusoft.sm.api.student.service.StudentService;

public class StudentServiceImpl implements StudentService {
	private StudentDao dao = new StudentDaoImpl();
	@Override
	public boolean insert(Student stu) {
		String maxCode =  dao.findMaxCode();
		stu.setStuCode(maxCode);
		
		int cnt = dao.insert(stu);
		if(cnt == 1) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean update(Student stu) {
		int cnt =  dao.update(stu);
		if(cnt == 1) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean delete(String id) {
		int cnt =  dao.delete(id);
		if(cnt == 1) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public Student findById(String id) {
		return dao.findById(id);
	}

	@Override
	public List<Student> findByCond() {
		return dao.findByCond();
	}

}
