package com.neusoft.sm.api.student.ctrl;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neusoft.sm.api.student.entity.Student;
import com.neusoft.sm.api.student.service.StudentService;
import com.neusoft.sm.api.student.service.impl.StudentServiceImpl;

@WebServlet(name="StudentQuerySlt", urlPatterns="/student/query")
public class StudentQuerySlt extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		StudentService service = new StudentServiceImpl();
		List<Student> list = service.findByCond();
		
		// list对象转化位json字符串
		ObjectMapper om = new ObjectMapper();
		String json = om.writeValueAsString(list);
		
		resp.setContentType("text/json;charset=utf-8");
		PrintWriter pw =  resp.getWriter();
		pw.write(json);
	}

}
