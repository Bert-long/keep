package com.neusoft.sm.api.codename.ctrl;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neusoft.sm.api.codename.entity.CodeName;
import com.neusoft.sm.api.codename.service.CodeNameService;
import com.neusoft.sm.api.codename.service.impl.CodeNameServiceImpl;
import com.neusoft.sm.common.util.StringUtil;

@WebServlet(name="CodeNameCtrl", urlPatterns="/api/getcodename")
public class CodeNameCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String groupCode = req.getParameter("groupcode");
		if(StringUtil.isEmpty(groupCode)) {
			throw new RuntimeException();
		}
		CodeNameService service = new CodeNameServiceImpl();
		List<CodeName> codenames = service.findByGroupId(groupCode);
		ObjectMapper om = new ObjectMapper();
		String json = om.writeValueAsString(codenames);
		
		resp.setContentType("text/json;charset=utf-8");
		resp.getWriter().println(json);
	}
}
