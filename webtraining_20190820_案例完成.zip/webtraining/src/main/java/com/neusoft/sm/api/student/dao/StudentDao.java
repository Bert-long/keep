package com.neusoft.sm.api.student.dao;

import java.util.List;

import com.neusoft.sm.api.student.entity.Student;

public interface StudentDao {
	public int insert(Student stu);
	public int update(Student stu);
	public int delete(String id);
	public Student findById(String id);
	public List<Student> findByCond();
	public String findMaxCode();
}
