SELECT 
    stu.id,
    stu.code,
    stu.name,
    stu.age,
    stu.sex,
    cn.name AS sex_name,
    stu.birthday,
    stu.class_id,
    cls.name AS cls_name
FROM stu_student stu
     INNER JOIN stu_class cls
		    on stu.class_id = cls.id
		 INNER JOIN code_name cn
		    on stu.sex = cn.`code`
				and cn.group_code = 'A01'