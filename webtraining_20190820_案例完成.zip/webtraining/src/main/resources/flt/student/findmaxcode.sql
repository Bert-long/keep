SELECT 
     CONCAT(
		   REPLACE(SUBSTRING(now() FROM 1 FOR 10),'-','') ,
		   (SUBSTRING(max(`code`) FROM 9 FOR 4) + 1))
FROM `stu_student`