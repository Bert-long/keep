update 
    stu_student
SET
    code=?,
    name=?,
    age=?,
    sex=?,
    birthday=?,
    class_id=?
where id = ?
    
    