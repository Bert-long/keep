SELECT 
    cls.id,
    cls.name
FROM stu_class cls