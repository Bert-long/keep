package test.lianxi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

import org.junit.Test;

public class TestJavaMysql {
	@Test
	public void testInsert() {
		Connection conn = null;
		PreparedStatement pst = null;
		try {
			String url = "jdbc:mysql://127.0.0.1:3306/sma?useUnicode=true&characterEncoding=UTF-8&allowMultiQueries=true&serverTimezone=GMT%2B8";
			// 1. 加载驱动
			Class.forName("com.mysql.cj.jdbc.Driver");
			// 2. 打开连接
			conn = DriverManager.getConnection(url, "root", "123456");
			System.out.println("连接成功");
			// 3. 准备sql语句
			pst = conn.prepareStatement("INSERT INTO stu_class VALUES(?,?,?,?)");
			String uuid = UUID.randomUUID().toString().replace("-", "");
			pst.setString(1, uuid);
			pst.setString(2, "201901RJ04");
			pst.setString(3, "JAVA4");
			pst.setString(4, "Z1112");
			// 4. 执行SQL语句   5. 接受数据
			int cnt = pst.executeUpdate();
			System.out.println("执行的结果：" + cnt);
			
			// 6. 关闭连接
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pst != null) {
					pst.close();
				}
				if(conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	@Test
	public void testUpdate() {
		Connection conn = null;
		PreparedStatement pst = null;
		try {
			String url = "jdbc:mysql://127.0.0.1:3306/sma?useUnicode=true&characterEncoding=UTF-8&allowMultiQueries=true&serverTimezone=GMT%2B8";
			// 1. 加载驱动
			Class.forName("com.mysql.cj.jdbc.Driver");
			// 2. 打开连接
			conn = DriverManager.getConnection(url, "root", "123456");
			System.out.println("连接成功");
			// 3. 准备sql语句
			String sql = "UPDATE stu_class ";
			sql += "SET code = ?, ";
			sql += "    name = ?, ";
			sql += "    zhuanye_id = ? ";
			sql += "WHERE id = ? ";
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, "201901RJ05");
			pst.setString(2, "JAVA5");
			pst.setString(3, "Z1112");
			pst.setString(4, "7a45cbe2eae4474c98bf797e95aa6799");
			// 4. 执行SQL语句   5. 接受数据
			int cnt = pst.executeUpdate();
			System.out.println("执行的结果：" + cnt);
			
			// 6. 关闭连接
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pst != null) {
					pst.close();
				}
				if(conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	@Test
	public void testQuery() {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet set = null;
		try {
			String url = "jdbc:mysql://127.0.0.1:3306/sma?useUnicode=true&characterEncoding=UTF-8&allowMultiQueries=true&serverTimezone=GMT%2B8";
			// 1. 加载驱动
			Class.forName("com.mysql.cj.jdbc.Driver");
			// 2. 打开连接
			conn = DriverManager.getConnection(url, "root", "123456");
			System.out.println("连接成功");
			// 3. 准备sql语句
			String sql = "SELECT * ";
			sql += "FROM stu_class ";
			sql += "WHERE zhuanye_id = ? ";
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, "Z1112");
			
			// 4. 执行SQL语句  
			set = pst.executeQuery();
			
			//  5. 接受数据
			while(set.next()) {
				String id = set.getString(1);
				String code = set.getString(2);
				String name = set.getString(3);
				String zhuye = set.getString(4);
				System.out.println(id + "," + code + "," + name + "," + zhuye);
			}
			
			// 6. 关闭连接
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(set != null) {
					set.close();
				}
				if(pst != null) {
					pst.close();
				}
				if(conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	@Test
	public void createUUid() {
		String uuid = UUID.randomUUID().toString().replace("-", "");
		System.out.println(uuid);
	}
}
