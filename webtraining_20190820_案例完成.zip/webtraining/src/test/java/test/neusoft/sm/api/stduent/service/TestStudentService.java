package test.neusoft.sm.api.stduent.service;

import java.util.Date;

import org.junit.Test;

import com.neusoft.sm.api.student.entity.Student;
import com.neusoft.sm.api.student.service.impl.StudentServiceImpl;

public class TestStudentService {
	@Test
	public void testInsert() {
		StudentServiceImpl service = new StudentServiceImpl();
		Student stu = new Student();
		stu.setStuName("张十");
		stu.setStuAge(20);
		stu.setStuSex("02");
		stu.setStuClassId("E11111");
		stu.setStuBirhday(new Date());
		boolean res = service.insert(stu);
		System.out.println("是否插入成功" + res);
	}
}
