package test.neusoft.sm.api.stduent.dao;

import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.neusoft.sm.api.student.dao.impl.StudentDaoImpl;
import com.neusoft.sm.api.student.entity.Student;

public class TestStudentDao {
	@Test
	public void testInsert() {
		StudentDaoImpl dao = new StudentDaoImpl();
		Student stu = new Student();
		stu.setStuCode("201603021013");
		stu.setStuName("张八");
		stu.setStuAge(20);
		stu.setStuSex("02");
		stu.setStuClassId("E11112");
		stu.setStuBirhday(new Date());
		int cnt = dao.insert(stu);
		System.out.println(cnt);
	}
	
	@Test
	public void testUpdate() {
		StudentDaoImpl dao = new StudentDaoImpl();
		Student stu = new Student();
		stu.setId("bec2d5c3d1bf4c1a8901223334e7eb1c");
		stu.setStuCode("201603021013");
		stu.setStuName("张八1");
		stu.setStuAge(21);
		stu.setStuSex("01");
		stu.setStuClassId("E11111");
		stu.setStuBirhday(new Date());
		int cnt = dao.update(stu);
		System.out.println(cnt);
	}
	
	@Test
	public void testFindall() {
		StudentDaoImpl dao = new StudentDaoImpl();
		List<Student> list = dao.findByCond();
		System.out.println(list);
	}
	
	@Test
	public void testFindbyid() {
		StudentDaoImpl dao = new StudentDaoImpl();
		Student student = dao.findById("S111112");
		System.out.println(student);
	}
}
