package test.neusoft.sm.api.codename.service;

import java.util.List;

import org.junit.Test;

import com.neusoft.sm.api.codename.entity.CodeName;
import com.neusoft.sm.api.codename.service.CodeNameService;
import com.neusoft.sm.api.codename.service.impl.CodeNameServiceImpl;

public class TestCodeNameService {
	@Test
	public void testFindByGroupId() {
		CodeNameService serive = new CodeNameServiceImpl();
		List<CodeName> codeNames = serive.findByGroupId("A01");
		System.out.println(codeNames.toString());
	}
}
