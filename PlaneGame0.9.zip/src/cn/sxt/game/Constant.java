package cn.sxt.game;

public class Constant {
	public static final int GAME_WIDTH = 500;
	public static final  int  GAME_HEIGHT = 500;
}
